package uk.heriotwatt.sef.model;

/**
 * Stores the different possible values of facilities.
 * 
 * @author fhb2
 * 
 */
public enum Facilities {

	GENERAL_FACILITIES, SEPERATE_BATHROOM, EN_SUITE, UNKNOWN

}
