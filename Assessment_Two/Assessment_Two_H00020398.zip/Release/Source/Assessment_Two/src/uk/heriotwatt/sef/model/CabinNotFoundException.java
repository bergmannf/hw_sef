package uk.heriotwatt.sef.model;

public class CabinNotFoundException extends Exception {

	/**
	 * Generated serialVersionUID to allow serialisation.
	 */
	private static final long serialVersionUID = -7740644730079198039L;

	public CabinNotFoundException(String msg) {
		super(msg);
	}
}
